import { createRouter,createWebHashHistory } from "vue-router";
import LoginPage from "@/views/LoginPage.vue";
import StuPage from "@/views/StuPage.vue";
import TeaPage from "@/views/TeaPage.vue";
import AdmPage from "@/views/AdmPage.vue";
import FinPage from "@/views/FinPage.vue";

const routes = [
    {
       path:"/",
       component:LoginPage
    },
    {
        path:"/student",
        component:StuPage
    },
    {
        path:"/teacher",
        component:TeaPage
    },
    {
        path:"/administrator",
        component:AdmPage
    },
    {
        path:"/finance",
        component:FinPage
    }

    
]

const router = createRouter({
    history:createWebHashHistory(),
    routes
})

export default router;