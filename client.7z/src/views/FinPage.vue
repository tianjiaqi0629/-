<template>
    <el-container class="container">
      <el-header class="header">
        <el-row>
          <el-col :span="16" class="headerlogo">
            <div>
              <img
                style="width:100px;height: 30px"
                src="../assets/lian.png"
                alt="无法显示图片"
              />
            </div>
          </el-col>
          <el-col :span="8" class="rightsection">
            <div>
              <span >欢迎您，财务</span>
              <span style="margin-left: 20px;" @click="signout">退出</span>
            </div>
          </el-col>
        </el-row>
      </el-header>
      <el-container>
        <el-aside class="aside">
          <el-menu class="menu"
            background-color=" #3A3A3A"
            text-color="#fff"
            active-text-color="#ffd04b"
            >
              <el-menu-item
                class="menuItem"
                @click="clicka"
                index="1"
              >
                <i class="el-icon-location"></i>
                <!--图标 -->
                <span>用户信息</span>
              </el-menu-item>
              <el-menu-item
                class="menuItem"
                @click="clickb"
                index="3"
              >
                <i class="el-icon-location"></i>
                <!--图标 -->
                <span>报销申请</span>
              </el-menu-item>
          </el-menu>
        </el-aside>
        <el-main class="main">
          <!-- <manage-sys-home :style="style"></manage-sys-home> -->
          <!--首页信息 -->
          <UserD v-if="a"></UserD>
          <PatentD v-if="b"></PatentD>
  
        </el-main>
      </el-container>
    </el-container>
  </template>
  
  <script >
  
  import PatentD from './PatentD.vue';
  import UserD from './UserD.vue';
 
  
  // import ManageSysHome from "./childComponent/ManageSysHome";
  export default {
    name: "StuPage",
    components: {
      PatentD,
      UserD
    },
    data() {
      return {
        style: {
          display: "block",
        },
        a:true,
        b:false,
      };
    },
    methods: {
      //退出
      signout() {
        this.$confirm("退出登录, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }).then(() => {
          this.$router.push({ path: "/" });
        });
      },
      clicka() {
        this.a=true;
        this.b=false;
        this.c=false;
      },
      clickb() {
        this.a=false;
        this.b=true;
        this.c=false;
      },    
      //回到首页
      clickTitle() {
        this.style.display = "block";
      },
    },
  };
  </script>
  <style scoped>
  .container {
    height: 100vh;
    font-size: 15px;
  }
  .header {
    background: #212121;
    color: #fff;
  }
  .aside {
    background: #3a3a3a;
    color: #fff;
    /* height: 100%; */
  }
  .menu {
    background: none;
    color: #fff;
  }
  .main {
    /* height: 100%; */
    color: #212121;
  }
  .headerlogo {
    line-height: 60px;
    margin-top: 10px;
  }
  .rightsection {
    line-height: 60px;
    text-align: center;
  }
  </style>
  