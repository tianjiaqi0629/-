<template>
    <div style="padding: 10px">
 

 
        <div style="margin: 10px 0">
            <el-table :data="tableData">
                <el-table-column prop="fund" label="专利名称" width="180"/>
                <el-table-column prop="name" label="作者姓名" width="180"/>
                <el-table-column prop="hash" label="哈希值"/>
                <el-table-column label="报销申请" width="140">
                    <template #default="scope">
                        <el-button link type="primary" size="small" @click="handleEdit(scope.row,scope.$index)" >审批</el-button>
                    </template>
                </el-table-column>
                <el-table-column prop="state" label="审批状态"/>
            </el-table>
        </div>
 
        <!--弹窗-->
        <el-dialog v-model="dialogFormVisible" title="报销申请" width="40%">
            <el-form :model="form" label-width="100px" style="padding-right:30px ">
                <el-form-item label="专利名称">
                    <el-input v-model="form.fund" autocomplete="off" disabled/>
                </el-form-item>
                <el-form-item label="作者姓名">
                    <el-input v-model="form.name" autocomplete="off" disabled/>
                </el-form-item>
                <el-form-item label="哈希值">
                    <el-input v-model="form.hash" autocomplete="off" disabled/>
                </el-form-item>
                <el-form-item label="描述">
                    <el-input
                        :rows="10"
                        type="textarea"
                        disabled
                        v-model="form.file"
                    />
                </el-form-item>
            </el-form>
            <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="save">通过</el-button>
      </span>
            </template>
        </el-dialog>
    </div>
</template>
<script setup>
 
    import {reactive, ref} from "vue";

    var tableData = ref([
        {
            fund: '专利一xxx',
            name: '张三',
            hash: 'b4ef99b2a2ea28d3c949c85563dc1bf4fcf0fde392cddffa3d66d4f433e43533',
            state: '未通过',
            file:''
        },
        {
            fund: '专利二xxx',
            name: '李四',
            hash: '1299cb7530d8dade21ee827cf38cd2bd046007c85a8eb5cf0ba159ddca9654e8',
            state: '未通过',
            file:''
        },
    ])
 
    var dialogFormVisible = ref(false)
    var form = reactive({})
    //全局保存编辑的行号
    const globalIndex = ref(-1)
 
    //新增数据 设置新的空的绑值对象 打开弹窗

    //保存数据，把数据插入到tableData中，并刷新页面，弹窗关闭
    const save = () => {
        if (globalIndex.value >= 0) {
            tableData.value[globalIndex.value].state='通过'
            globalIndex.value = -1
        } else {
            //新增
            tableData.value.push(form)
        }
 
        dialogFormVisible.value = false
    }
 
    //编辑数据 先赋值到表单再弹窗
    const handleEdit = (row, index) => {
        const newObj = Object.assign({}, row)
        form = reactive(newObj)
        //把当前编辑的行号赋值给全局保存的行号
        globalIndex.value = index
        console.log(globalIndex.value)
        dialogFormVisible.value = true
    }
 
    //删除数据 从index位置开始，删除一行即可

 
    //查询数据

 
 
</script>