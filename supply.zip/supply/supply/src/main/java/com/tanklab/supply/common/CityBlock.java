package com.tanklab.supply.common;
import lombok.SneakyThrows;
import org.jetbrains.annotations.NotNull;

import java.util.Random;
public enum CityBlock {
    Paris("http://116.204.29.222:10012","0847b4b2f1fe3944bdb62be2f528d3a1a2cca2b957df7fba422830c1c7a14bf6",15987,"eth"),//国外链
    Tianjin("http://116.204.29.222:10016","0847b4b2f1fe3944bdb62be2f528d3a1a2cca2b957df7fba422830c1c7a14bf6",15988,"h2chain"),//国内链
    Beijing("http://116.204.29.222:12301","",0,"chainmaker");
//    Tokyo("Chain 3",3),
//    London("Chain 4",4);

    public String netWorkUrl;
    public String walletKey;
    public long chainId;
    public String type;
    CityBlock(String netWorkUrl,String walletKey,long chainId,String type) {
        this.netWorkUrl = netWorkUrl;
        this.walletKey = walletKey;
        this.chainId = chainId;
        this.type = type;
    }

    @SneakyThrows
    public static String generate_tx_id(@NotNull CityBlock cb){
        Thread.sleep(3000);
        String txid = "";
        if (cb.type.equals("eth")){
            txid = "0x";
            for (int i = 0 ; i < 64;i++){
                Random random = new Random();
                int number = random.nextInt(16);
                txid += Integer.toHexString(number);
            }
        }
        if (cb.type.equals("chainmaker")){
            int l = "75109020f396aca88a12ca807612e27e03a3180fb40c0a5108b6bd6c38c47".length();
            txid = "17a";
            for (int i = 0 ; i < l;i++){
                Random random = new Random();
                int number = random.nextInt(16);
                txid += Integer.toHexString(number);
            }
        }
        if (cb.type.equals("h2chain")){
            txid = "0x";
            int l = "385ac730303c4e839fc89c6d74c282a4640fc633d63f97f4e1135e1cba3be545".length();
            for (int i = 0 ; i < l;i++){
                Random random = new Random();
                int number = random.nextInt(16);
                txid += Integer.toHexString(number);
            }
        }

        return txid;
    }
    public static void main(String[] args) {
        System.out.println(generate_tx_id(CityBlock.Tianjin));
    }
}
